#include <ncurses.h>
#include <iostream>
#include <ctime>
#include <time.h>
#include <locale.h>
#include <list>
#include "Snake.h"
#include "Snake_map.h"
#include "Display.h"
#include "Item.h"

using namespace std;

// 해야될 것
// 다양한 맵 만들기
// item 먹는 것
// 차원의 문(?) -> 이동까지 구현필요
// 게임 종료시
// 포인트와 미션 구현


int kbhit(void) {
    int ch = getch();
    if (ch != ERR) {
        ungetch(ch);
        return 1;
    }
    else {
        return 0;
    }
}


const char* returnScore(int score){
    string tmp = to_string(score);
    char const *result = tmp.c_str();
    return result;
}

int stage = 1;


int main(){
    srand(time(NULL));
    chooseMap(stage);
    map_init();

    WINDOW* snake_win;
    WINDOW* point_win;
    WINDOW* mission_win;

    Snake sk = Snake();
    Point *p = new Point();

    setlocale(LC_ALL, "");

    initscr();
    resize_term(60, 100);
    
    colorSetting();
    border('*', '*', '*', '*', '*', '*', '*', '*');
    mvprintw(1, 1, "SNAKE GAME");
    mvprintw(2, 1, "STAGE : %d", stage);
    refresh();

    //디스플레이 하드코딩 된 부분 수정 필요
    snake_win = newwin(30, 60, 3, 3);
    wbkgd(snake_win, COLOR_PAIR(1));
    wattron(snake_win, COLOR_PAIR(8));
    mvwprintw(snake_win, 1, 1, "Snake_game window");
    wborder(snake_win, '|', '|', '-', '-', '+', '+', '+', '+');
    wrefresh(snake_win);


    point_win = newwin(15, 29, 3, 64);
    wbkgd(point_win, COLOR_PAIR(1));
    wattron(point_win, COLOR_PAIR(8));    

    //Score 표시
    updatePoint(point_win, p);
    wborder(point_win, '|', '|', '-', '-', '+', '+', '+', '+');
    wrefresh(point_win);


    mission_win = newwin(15, 29, 18, 64);
    wbkgd(mission_win, COLOR_PAIR(1));
    wattron(mission_win, COLOR_PAIR(8));
    mvwprintw(mission_win, 1, 1, "Mission");   
    mvwprintw(mission_win, 2, 1, "B: 10 ("); mvwprintw(mission_win, 2, 9, ")");
    mvwprintw(mission_win, 3, 1, "+: 5  ("); mvwprintw(mission_win, 3, 9, ")");
    mvwprintw(mission_win, 4, 1, "-: 2  ("); mvwprintw(mission_win, 4, 9, ")");
    mvwprintw(mission_win, 5, 1, "G: 1  ("); mvwprintw(mission_win, 5, 9, ")");
    wborder(mission_win, '|', '|', '-', '-', '+', '+', '+', '+');


    wrefresh(mission_win);
    wrefresh(point_win);
    wrefresh(mission_win);



    int key;
    keypad(stdscr, TRUE);
    curs_set(0);
    noecho();
    nodelay(stdscr, TRUE);
    scrollok(stdscr, TRUE);


    clock_t startClock;
    clock_t endClock;

    startClock = clock();
    //초기맵 설정
    Item item = Item();
    item.setBody(sk.getBody(), sk.getLength());

    pair<int, int> growitem = item.getGrowItemPosition();
    map[growitem.first][growitem.second] = 5;

    pair<int, int> poisonitem = item.getPoisonItemPosition();
    map[poisonitem.first][poisonitem.second] = 6;
    
    int countSecond = 0;
    int snakeBodyMaxLength = 3;
    



    while (1) {
        if (sk.length < 3){
            break;
        }
        if (kbhit()) {
            key = getch();
            if (key == 259) {
                // printw("up");
                sk.turnDirection(NORTH);
            }
            else if (key == 260) {
                // printw("left");
                sk.turnDirection(WEST);
            }
            else if (key == 258) {
                // printw("down");
                sk.turnDirection(SOUTH);
            }
            else if (key == 261) {
                // printw("right");
                sk.turnDirection(EAST);
            }
            refresh();
        }
        endClock = clock();

        // 지렁이의 헤드가 포지션을 지나면 새로운 값 생성 후 지렁이 사이즈 하나 늘림
        // 개선점 : 헤드가 먹이를 먹자마자 새로운 grow item이 생겨야 하고 바로 body 사이즈가 늘어나야함.
        if (growitem.first == sk.heady && growitem.second == sk.headx) {
            map[growitem.first][growitem.second] = 0;
            item.setBody(sk.getBody(), sk.getLength());
            growitem = item.getGrowItemPosition();
            map[growitem.first][growitem.second] = 5;

        }

        // 포인즌 아이템이 안뜸 초기에 뜨다가 말음. 
        if (poisonitem.first == sk.heady && poisonitem.second == sk.headx) {
            map[poisonitem.first][poisonitem.second] = 0;
            item.setBody(sk.getBody(), sk.getLength());
            poisonitem = item.getPoisonItemPosition();
            map[poisonitem.first][poisonitem.second] = 6;

        }

        if (countSecond == 30){
            map[growitem.first][growitem.second] = 0;
            item.setBody(sk.getBody(), sk.getLength());
            growitem = item.getGrowItemPosition();
            map[growitem.first][growitem.second] = 5;

            map[poisonitem.first][poisonitem.second] = 0;
            item.setBody(sk.getBody(), sk.getLength());
            poisonitem = item.getPoisonItemPosition();
            map[poisonitem.first][poisonitem.second] = 6;

            countSecond = 0;
        }

        // 5초가 지나면 아이템 재설정하는 건 민재형이랑 코드리뷰하고 설정
        //일정간격 display
        if ((float)(endClock - startClock) / CLOCKS_PER_SEC >= 0.3) {
            countSecond++;

            if (!sk.move(p)) {
                break;
            }
            startClock = endClock;

            drawGate();
            updatePoint(point_win, p);
            draw_snakewindow(snake_win);
        }
    }
    // wborder(snake_win, '|','|','-','-','+','+','+','+');
    getch();
    delwin(snake_win);
    endwin();
    return 0;
}
