#include "Display.h"

void draw_snakewindow(WINDOW* snake_win) {
    for (int i = 4; i < MAP_SIZE + 4; i++) {
        int j = 4;
        for (; j < MAP_SIZE + 4; j++) {
            if (map[i - 4][j - 4] == 0) { //white(빈칸)
                wattron(snake_win, COLOR_PAIR(1));
                mvwprintw(snake_win, i, j * 2, "  ");
                // attroff(COLOR_PAIR(1));
            }
            else if (map[i - 4][j - 4] == 1 || map[i - 4][j - 4] == 2) { //wall
                wattron(snake_win, COLOR_PAIR(2));
                mvwprintw(snake_win, i, j * 2, "  ");
                // attroff(COLOR_PAIR(2));
            }
            else if (map[i - 4][j - 4] == 3) {  //head of snake
                wattron(snake_win, COLOR_PAIR(3));
                mvwprintw(snake_win, i, j * 2, "  ");
                // attroff(COLOR_PAIR(3));
            }
            else if (map[i - 4][j - 4] == 4) {  //head of snake
                wattron(snake_win, COLOR_PAIR(4));
                mvwprintw(snake_win, i, j * 2, "  ");
            }
            else if (map[i - 4][j - 4] == 5) {  // growth item
                wattron(snake_win, COLOR_PAIR(5));
                mvwprintw(snake_win, i, j * 2, "  ");
            }
            else if (map[i - 4][j - 4] == 6) {  //posion item
                wattron(snake_win, COLOR_PAIR(6));
                mvwprintw(snake_win, i, j * 2, "  ");
            }
            else if (map[i - 4][j - 4] == 7) {  //Gate
                wattron(snake_win, COLOR_PAIR(7));
                mvwprintw(snake_win, i, j * 2, "  ");
            }
            else if (map[i - 4][j - 4] == 8) {  //Gate
                wattron(snake_win, COLOR_PAIR(2));
                mvwprintw(snake_win, i, j * 2, "  ");
            }
        }
    }
    wrefresh(snake_win);
}


void colorSetting(){
    start_color();
    init_pair(1, COLOR_WHITE, COLOR_WHITE);
    init_pair(2, COLOR_BLACK, COLOR_BLACK);
    init_pair(3, COLOR_MAGENTA, COLOR_MAGENTA);
    init_pair(4, COLOR_CYAN, COLOR_CYAN);
    init_pair(5, COLOR_GREEN, COLOR_GREEN);
    init_pair(6, COLOR_RED, COLOR_RED);
    init_pair(7, COLOR_YELLOW, COLOR_YELLOW);
    init_pair(8, COLOR_BLACK, COLOR_WHITE);
}



void updatePoint(WINDOW* point_win, Point *p){
    //이미 써져있는 것 초기화
    for(int i=1; i<=5; i++){
        mvwprintw(point_win, i, 1, "                  ");
    }
    p->updateMaxLength();
    mvwprintw(point_win, 1, 1, "Score_board");
    mvwprintw(point_win, 2, 1, "B: %d / %d", p->getCurrentLength(), p->getMaxLength());
    mvwprintw(point_win, 3, 1, "+: %d", p->getGrowItem());
    mvwprintw(point_win, 4, 1, "-: %d", p->getPoisonItem());
    mvwprintw(point_win, 5, 1, "G: %d", p->getUseGate());
    wrefresh(point_win);
}