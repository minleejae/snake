#include <iostream>
#include "Mission.h"

Mission::Mission() {
    B = 10;
    growItem = 5;
    poisonItem = 2;
    useGate = 1;
};


int Mission::getB(){
    return B;
}
int Mission::getGrowItem(){
    return growItem;
}
int Mission::getPoisonItem(){
    return poisonItem;
}
int Mission::getUseGate(){
    return useGate;
}


void Mission::setB(int x){
    B = x;
}
void Mission::setGrowItem(int x){
    growItem = x;
}
void Mission::setPoisonItem(int x){
    poisonItem = x;
}
void Mission::setUseGate(int x){
    useGate = x;
}