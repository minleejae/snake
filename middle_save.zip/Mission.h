#include <iostream>

class Mission {
private:
    int B;
    int growItem;
    int poisonItem;
    int useGate;
public:
    Mission();
    int getB();
    int getGrowItem();
    int getPoisonItem();
    int getUseGate();

    void setB(int b);
    void setGrowItem(int x);
    void setPoisonItem(int x);
    void setUseGate(int x);
};