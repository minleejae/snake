#include <ncurses.h>
#include "Snake_map.h"
#include "Point.h"
#include "Mission.h"

void draw_snakewindow(WINDOW* snake_win);
void colorSetting();

void updatePoint(WINDOW* point_win, Point *p);