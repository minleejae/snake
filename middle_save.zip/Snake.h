#include <iostream>
#include <deque>
#include "Snake_map.h"
#include "Point.h"
#ifndef __SNAKE__
#define __SNAKE__

//snake의 방향
enum direction { WEST, NORTH, EAST, SOUTH }; //서: 0 북:1 동:2 남:3

class Snake {
public:
    int curDirection = WEST;
    int headx, heady;
    int length = 3;
    std::deque<std::pair<int, int> > body; // (y,x)

    Snake();
    std::deque<std::pair<int, int> > getBody();
    int getLength();
    bool turnDirection(int key);
    bool move(Point *p);
    bool check();
};

#endif