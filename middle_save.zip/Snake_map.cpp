#include <iostream>
#include "Snake_map.h"

int waitGate = 1;
int gate[2][GATE_SIZE] = { { 0, 0 }, { 0, 0 } };


int map[MAP_SIZE][MAP_SIZE];
int map1[5][GATE_SIZE] = { { 2, 2 }, { 2, 3 }, { 2, 4 }, { 2, 5 }, { 2, 6 } };
int map2[5][GATE_SIZE] = { { 3, 2 }, { 3, 3 }, { 3, 4 }, { 3, 5 }, { 3, 6 } };
int map3[5][GATE_SIZE] = { { 5, 2 }, { 5, 3 }, { 5, 4 }, { 5, 5 }, { 5, 6 } };
int map4[5][GATE_SIZE] = { { 5, 2 }, { 5, 3 }, { 5, 4 }, { 5, 5 }, { 6, 6 } };
int map5[5][GATE_SIZE] = { { 6, 2 }, { 6, 3 }, { 6, 4 }, { 6, 5 }, { 6, 6 } };
int walls[5][GATE_SIZE] = { { 0, 0 }, { 0, 0 }, { 0, 0 }, { 0, 0 }, { 0, 0 } };

void map_init() {
    for (int i = 0; i < MAP_SIZE; i++) {
        map[i][MAP_SIZE - 1] = 1;
        map[i][0] = 1;
        map[MAP_SIZE - 1][i] = 1;
        map[0][i] = 1;
    }
    map[0][0] = 2;
    map[0][MAP_SIZE - 1] = 2;
    map[MAP_SIZE - 1][MAP_SIZE - 1] = 2;
    map[MAP_SIZE - 1][0] = 2;

    map[MAP_SIZE / 2][MAP_SIZE / 2] = 3;
    map[MAP_SIZE / 2][MAP_SIZE / 2 + 1] = 3;
    map[MAP_SIZE / 2][MAP_SIZE / 2 - 1] = 4;
}

void chooseMap(int stage) {
    for (int i = 0; i < 5; i++)
    {
        for (int j = 0; j < 2; j++)
            switch (stage)
            {
            case 0:
                walls[i][j] = map1[i][j];
                break;
            case 1:
                walls[i][j] = map2[i][j];
                break;
            case 2:
                walls[i][j] = map3[i][j];
                break;
            case 3:
                walls[i][j] = map4[i][j];
                break;
            case 4:
                walls[i][j] = map5[i][j];
                break;
            }
    }
}


//벽 생성하기 위한 함수 
void setPosition(int& x, int& y)
{
    int isSide = (rand() % 2);
    int xORy = (rand() % 2);
    int zeroOr20 = (rand() % 2);
    if (isSide)
    {
        // cout << "inside " << endl;
        if (xORy)
        {
            if (zeroOr20)
            {
                x = 20;
                y = rand() % 19 + 1;
            }
            else
            {
                x = 0;
                y = rand() % 19 + 1;
            }
        }
        else
        {
            if (zeroOr20)
            {
                x = rand() % 19 + 1;
                y = 20;
            }
            else
            {
                x = rand() % 19 + 1;
                y = 0;
            }
        }
    }
    else
    {
        // cout << "outSide " << endl;
        int choose = (rand() % 5);
        y = walls[choose][0];
        x = walls[choose][1];
    }
}

void makeGate()
{
    int x1, y1, x2, y2;
    x1 = y1 = x2 = y2 = 0;
    while (x1 == x2 and y1 == y2)
    {
        setPosition(x1, y1);
        setPosition(x2, y2);
    };
    gate[0][0] = y1;
    gate[0][1] = x1;
    gate[1][0] = y2;
    gate[1][1] = x2;
    // cout << x1 << " " << y1 << " " << x2 << " " << y2 << endl;
}


void drawGate() {
    for (int i = 0; i < 5; i++)
    {
        map[walls[i][0]][walls[i][1]] = 1;
    }
    // view gate
    if ((gate[0][0] + gate[0][1] + gate[1][0] + gate[0][1]) > 0)
    {
        map[gate[0][0]][gate[0][1]] = 7;
        map[gate[1][0]][gate[1][1]] = 7;
    }
}