#include <iostream>
#include <deque>

class Item {
    int grow_x, grow_y, poison_x, poison_y;
    int cnt;
    int bodyLength;
    int body[][2];
public:
    Item();
    // snake의 바디값 설정
    void setBody(std::deque<std::pair<int, int> >snake, int length);
    // 바디값이 아닌 위치를 범위 내에서 랜덤 설정(1~19)
    // posisonItem이랑 위치 겹치면 안되기 때문에 main에서 비교 후 다시 설정해주는 작업해야됨
    std::pair<int, int> getGrowItemPosition();
    std::pair<int, int> getPoisonItemPosition();
    bool positionIsSuited(int y, int x);
};