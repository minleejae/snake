#include <iostream>
#include "Snake.h"

using namespace std;

Snake::Snake() {
    heady = MAP_SIZE / 2;
    headx = MAP_SIZE / 2 - 1;
    body.push_back({ MAP_SIZE / 2, MAP_SIZE / 2 + 1 });
    body.push_back({ MAP_SIZE / 2, MAP_SIZE / 2 });
    body.push_back({ MAP_SIZE / 2, MAP_SIZE / 2 - 1 });
}

deque<pair<int, int>> Snake::getBody() {
    return body;
}

int Snake::getLength() {
    return length;
}
//입력된 키를 기준으로 방향전환
//방향전환시 죽는 경우 있음
bool Snake::turnDirection(int key) {
    if (abs(key - curDirection) == 2) return false;
    // else if(curDirection==WEST){


    // }else if(curDirection==NORTH){

    // }else if(curDirection==EAST){

    // }else if(curDirection==SOUTH){

    // }
    curDirection = key;
    return true;
}

//현재 방향을 기준으로 움직임
bool Snake::move(Point *p) {
    int pop_fronty = body.front().first;
    int pop_frontx = body.front().second;

    map[pop_fronty][pop_frontx] = 0;
    map[heady][headx] = 4;

    if (curDirection == 0) {
        headx -= 1;
    }
    else if (curDirection == 1) {
        heady -= 1;
    }
    else if (curDirection == 2) {
        headx += 1;
    }
    else {
        heady += 1;
    }

    // item 만났을 때 바디값 조절
    if (map[heady][headx] == 5) {
        //point의 growitem 증가 
        p->addGrowItem();
        p->addCurrentLength();

        map[pop_fronty][pop_frontx] = 4;
        length++;// 바디값이 늘어난 것을 명시, item 클래스에 바디 길이를 체크할 때 활용하기 때문에.
    }
    else if (map[heady][headx] == 6) {
        p->addPoisonItem();

        body.pop_front();
        int body_lasty = body.front().first;
        int body_lastx = body.front().second;
        body.pop_front();
        map[body_lasty][body_lastx] = 0;
        length--;
    }
    else {
        body.pop_front();
    }

    //map, wall
    if (map[heady][headx] == 1)
    { // 벽
        return false;
    }

    // count wait gate
    if (waitGate == 0)
    {
        makeGate();
    }
    waitGate--;
    if (map[heady][headx] == 7)
    {
        p->addUseGate();

        headx = (headx == gate[0][1]) ? gate[1][1] : gate[0][1];
        heady = (heady == gate[0][0]) ? gate[1][0] : gate[0][0];

        // 게이트가 벽에 있을 때 방향 조절
        if (headx == 0)
            curDirection = EAST;
        if (headx == 20)
            curDirection = WEST;
        if (heady == 0)
            curDirection = SOUTH;
        if (heady == 20)
            curDirection = NORTH;

        // 게이트가 맵 가운데에 있을 때
        // 원래 방향이 동쪽일 때
        if (curDirection == EAST && map[heady][headx + 1] == 1)
        {
            if (map[heady + 1][headx] == 1)
            {
                if (map[heady - 1][headx] == 1)
                {
                    if (map[heady][headx - 1] == 1)
                    {
                        // cout << "SETTING DIRECTION ERROR" << endl;
                    }
                    else
                    {
                        curDirection = WEST;
                    }
                }
                else
                {
                    curDirection = NORTH;
                }
            }
            else
            {
                curDirection = SOUTH;
            }
        }
        // 원래 방향이 서쪽일 때
        else if (curDirection == WEST && map[heady][headx - 1] == 1)
        {
            if (map[heady - 1][headx] == 1)
            {
                if (map[heady + 1][headx] == 1)
                {
                    if (map[heady][headx + 1] == 1)
                    {
                        // cout << "SETTING DIRECTION ERROR" << endl;
                    }
                    else
                    {
                        curDirection = EAST;
                    }
                }
                else
                {
                    curDirection = SOUTH;
                }
            }
            else
            {
                curDirection = NORTH;
            }
        }
        // 원래 방향이 남쪽일 때
        else if (curDirection == SOUTH && map[heady + 1][headx] == 1)
        {
            if (map[heady][headx - 1] == 1)
            {
                if (map[heady][headx + 1] == 1)
                {
                    if (map[heady - 1][headx] == 1)
                    {
                        // cout << "SETTING DIRECTION ERROR" << endl;
                    }
                    else
                    {
                        curDirection = NORTH;
                    }
                }
                else
                {
                    curDirection = EAST;
                }
            }
            else
            {
                curDirection = WEST;
            }
        }
        // 원래 방향이 북쪽일 때
        else if (curDirection == NORTH && map[heady - 1][headx] == 1)
        {
            if (map[heady][headx + 1] == 1)
            {
                if (map[heady][headx - 1] == 1)
                {
                    if (map[heady + 1][headx] == 1)
                    {
                        // cout << "SETTING DIRECTION ERROR" << endl;
                    }
                    else
                    {
                        curDirection = SOUTH;
                    }
                }
                else
                {
                    curDirection = WEST;
                }
            }
            else
            {
                curDirection = EAST;
            }
        }

        //door 이후로 이동하게끔 추가 
        if(curDirection==EAST){
            headx++;
        }
        else if(curDirection==WEST){
            headx--;
        }
        else if(curDirection==SOUTH){
            heady++;
        }
        else if(curDirection==NORTH){
            heady--;
        }
    }


    //벽이나 어떤 이벤트 생기나 확인
    if (!check()) {
        return false;
    }

    map[heady][headx] = 3;
    body.push_back({ heady,headx });
    return true;
}


bool Snake::check() {
    if (map[heady][headx] == 1) {
        return false;
    }
    return true;
}
