#include <iostream>
#ifndef __SNAKE_MAP__
#define __SNAKE_MAP__
#define MAP_SIZE 21
#define GATE_SIZE 2

extern int waitGate;
extern int gate[][GATE_SIZE];
extern int map[MAP_SIZE][MAP_SIZE];
extern int map1[][GATE_SIZE];
extern int map2[][GATE_SIZE];
extern int map3[][GATE_SIZE];
extern int map4[][GATE_SIZE];
extern int walls[][GATE_SIZE];

void map_init();
void chooseMap(int stage);


//gate관련
void makeGate();
void drawGate();
void setPosition(int& x, int& y);


#endif