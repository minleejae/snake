#include <iostream>
#ifndef __POINT__
#define __POINT__

class Point {
private:
    int currentLength;
    int maxLength;
    int growItem;
    int poisonItem;
    int useGate;
public:
    Point();
    int getCurrentLength();
    int getMaxLength();
    int getGrowItem();
    int getPoisonItem();
    int getUseGate();
    
    void updateMaxLength();
    void addCurrentLength();
    void minusCurrentLength();
    void addMaxLength();
    void addGrowItem();
    void addPoisonItem();
    void addUseGate();
};

#endif