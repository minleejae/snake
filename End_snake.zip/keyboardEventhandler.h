#include <ncurses.h>
#include <iostream>
#include "Snake.h"


int kbhit();
bool keyEventHandler(Snake& sk);